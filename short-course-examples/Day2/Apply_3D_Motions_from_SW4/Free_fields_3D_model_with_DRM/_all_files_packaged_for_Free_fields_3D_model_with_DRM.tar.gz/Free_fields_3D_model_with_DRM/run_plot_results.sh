
python extract_node_disp.py soil_foundation_motion.h5.feioutput 30239 x

python extract_node_acce.py soil_foundation_motion.h5.feioutput 30239 x

python extract_node_spectrum.py soil_foundation_motion.h5.feioutput 2685 x



