#!/bin/bash

## run SW4 

cd SW4_motion

./run_SW4.sh

echo "<========== Finish generating 3D motion ==============>"