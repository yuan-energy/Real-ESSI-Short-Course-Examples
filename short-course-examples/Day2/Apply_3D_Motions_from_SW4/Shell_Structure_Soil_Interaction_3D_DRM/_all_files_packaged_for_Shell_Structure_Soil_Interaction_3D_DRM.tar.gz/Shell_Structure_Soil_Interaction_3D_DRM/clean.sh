#!/bin/bash

## delete old DRMinput file

rm -rf *.hdf5

rm -rf *.feioutput

rm -rf *.log

rm -rf RealESSI_VERSION_INFO.txt