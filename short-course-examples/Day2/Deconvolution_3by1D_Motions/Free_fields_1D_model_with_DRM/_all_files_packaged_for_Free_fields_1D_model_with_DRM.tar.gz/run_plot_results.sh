
python extract_node_disp.py DRM1D_motion.h5.feioutput 5 x

python extract_node_acce.py DRM1D_motion.h5.feioutput 5 x

python extract_node_spectrum.py DRM1D_motion.h5.feioutput 5 x



