python plot_freq_all.py
python plot_freq_all_wave.py
python plot_time_all.py
python plot_time_all_wave.py
