#!/bin/bash

# Postprocessing with paraview
paraview Experiment1_StaticPushover.h5.feioutput
