

python compare_top_acc.py DRM1D_motion_node_12_x_acce.txt DRM1D_motion_node_5_x_acce.txt






