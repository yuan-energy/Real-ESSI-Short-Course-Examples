#!/bin/bash

# Execute sequential essi with the file main.fei
essi -f main.fei

# If one wants to measure the time and save the terminal logs.
# script -c "time essi -f main.fei" terminal.log
