#!/bin/bash

# Execute sequential essi with the file main.fei

# Meanwhile, measure the time and script the terminal logs.
script -c "time essi -f main.fei" benchmark.txt
