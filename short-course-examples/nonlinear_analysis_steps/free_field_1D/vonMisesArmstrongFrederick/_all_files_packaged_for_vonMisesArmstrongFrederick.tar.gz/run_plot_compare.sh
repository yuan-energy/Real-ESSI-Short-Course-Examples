#!/bin/bash
# Format
# python script_path/script.py file1 file2

# Example:

# Compare the acceleration at the node-21 and node-5 in x direction. 
python postprocess/compare_top_acc.py DRM1D_motion_node_21_x_acce.txt DRM1D_motion_node_6_x_acce.txt



