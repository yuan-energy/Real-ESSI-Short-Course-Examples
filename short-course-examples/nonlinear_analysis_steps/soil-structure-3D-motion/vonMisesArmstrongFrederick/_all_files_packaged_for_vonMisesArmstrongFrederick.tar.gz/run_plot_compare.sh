

python compare_top_acc.py sw4_free_field_center_ax.txt shell_structure_motion_node_38_x_acce.txt






