
python extract_node_disp.py shell_structure_motion.h5.feioutput 38 x

python extract_node_acce.py shell_structure_motion.h5.feioutput 38 x

python extract_node_spectrum_in_freq.py shell_structure_motion.h5.feioutput 3195 x

python extract_node_spectrum_in_period.py shell_structure_motion.h5.feioutput 3195 x



