# Format
# python script_path/script.py file1 file2

# Example:

# Compare the acceleration at the node-22793 and node-42143 in x direction. 

python postprocess/compare_top_acc.py soil_foundation_motion_node_22793_x_acce.txt soil_foundation_motion_node_42143_x_acce.txt






