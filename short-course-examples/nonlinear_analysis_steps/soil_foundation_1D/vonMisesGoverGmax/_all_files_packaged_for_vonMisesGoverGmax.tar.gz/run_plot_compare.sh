

python compare_top_acc.py sw4_free_field_center_ax.txt DRM1D_motion_node_5_x_acce.txt






