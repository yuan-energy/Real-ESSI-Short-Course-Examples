#!/bin/bash
# Format
# python script_path/script.py file1 file2

# Example:

# Compare the acceleration at the node-16 and node-9 in x direction. 
python postprocess/compare_top_acc.py DRM1D_motion_node_16_x_acce.txt DRM1D_motion_node_9_x_acce.txt



