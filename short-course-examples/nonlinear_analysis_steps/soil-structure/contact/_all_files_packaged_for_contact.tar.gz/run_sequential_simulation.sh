#!/bin/bash
script -c "time essi -f main.fei" benchmark.txt
