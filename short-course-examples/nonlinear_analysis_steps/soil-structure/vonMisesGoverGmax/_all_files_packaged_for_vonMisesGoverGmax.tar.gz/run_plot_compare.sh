# Format
# python script_path/script.py file1 file2

# Example:

# Compare the acceleration at the node-3391 and node-38 in x direction. 

python postprocess/compare_top_acc.py shell_structure_motion_node_3391_x_acce.txt shell_structure_motion_node_38_x_acce.txt






