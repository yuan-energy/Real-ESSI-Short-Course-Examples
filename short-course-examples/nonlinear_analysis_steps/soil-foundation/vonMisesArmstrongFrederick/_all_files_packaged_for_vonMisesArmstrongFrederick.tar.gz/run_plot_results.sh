
python extract_node_disp.py soil_foundation_motion.h5.feioutput 30239 x

python extract_node_acce.py soil_foundation_motion.h5.feioutput 30239 x

python extract_node_spectrum_in_freq.py soil_foundation_motion.h5.feioutput 2685 x

python extract_node_spectrum_in_period.py soil_foundation_motion.h5.feioutput 2685 x



