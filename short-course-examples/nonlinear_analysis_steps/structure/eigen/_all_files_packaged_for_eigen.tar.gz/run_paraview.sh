#!/bin/bash

# Run Paraview
paraview shell_structure_eigen.h5.feioutput

