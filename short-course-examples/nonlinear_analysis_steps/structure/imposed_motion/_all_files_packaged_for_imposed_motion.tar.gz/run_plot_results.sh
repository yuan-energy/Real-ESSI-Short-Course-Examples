
python postprocess/extract_node_disp.py shell_structure_imposed_motion.h5.feioutput 38 x

python postprocess/extract_node_acce.py shell_structure_imposed_motion.h5.feioutput 38 x

python postprocess/extract_node_spectrum_in_freq.py shell_structure_imposed_motion.h5.feioutput 38 x

python postprocess/extract_node_spectrum_in_period.py shell_structure_imposed_motion.h5.feioutput 38 x



