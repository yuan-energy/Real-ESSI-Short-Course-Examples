# Format
# python script_path/script.py file1 file2

# Example:

# Compare the acceleration at the node-11685 and node-4454 in x direction. 

python postprocess/compare_top_acc.py DRM3D_motion_node_11685_x_acce.txt DRM3D_motion_node_4454_x_acce.txt






