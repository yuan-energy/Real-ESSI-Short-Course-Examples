
python extract_node_disp.py DRM3D_motion.h5.feioutput 4454 x

python extract_node_acce.py DRM3D_motion.h5.feioutput 4454 x

python extract_node_spectrum_in_freq.py DRM3D_motion.h5.feioutput 4454 x

python extract_node_spectrum_in_period.py DRM3D_motion.h5.feioutput 4454 x



