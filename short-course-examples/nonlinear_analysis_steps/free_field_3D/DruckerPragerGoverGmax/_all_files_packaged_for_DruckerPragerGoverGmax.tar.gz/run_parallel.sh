script -c "time mpirun -np 4 essi_parallel -f main.fei" benchmark.txt


