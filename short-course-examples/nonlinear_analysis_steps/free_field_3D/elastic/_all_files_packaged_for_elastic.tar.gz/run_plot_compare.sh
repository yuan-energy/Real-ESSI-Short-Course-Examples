

python compare_top_acc.py DRM3D_motion_node_11685_x_acce.txt DRM3D_motion_node_4454_x_acce.txt






