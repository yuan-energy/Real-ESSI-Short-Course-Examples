#!/bin/bash

# Postprocessing with paraview
paraview Beam_Pushover.h5.feioutput
