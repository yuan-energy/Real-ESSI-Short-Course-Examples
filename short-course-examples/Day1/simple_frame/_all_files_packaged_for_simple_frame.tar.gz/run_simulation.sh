rm -f *.feioutput
rm -f essi*.log
essi -f main.fei



# paraview FiberBeam_PushOver_Pushover.h5.feioutput