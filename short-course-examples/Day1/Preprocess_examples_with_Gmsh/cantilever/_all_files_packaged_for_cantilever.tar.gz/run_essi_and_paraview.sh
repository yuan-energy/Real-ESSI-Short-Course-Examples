
# Run check model
essi -f main.fei

# Run paraview 
paraview DRM2D_Self_weight.h5.feioutput
