
# Run check model
essi -f main.fei

# Run paraview 
paraview Solids_With_Beam_And_Shells_Nodal_Load.h5.feioutput
