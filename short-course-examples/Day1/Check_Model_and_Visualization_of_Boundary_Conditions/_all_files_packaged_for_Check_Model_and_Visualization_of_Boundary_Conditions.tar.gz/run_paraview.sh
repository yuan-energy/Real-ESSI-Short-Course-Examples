#!/bin/bash

# Postprocessing with paraview
paraview test_Initial_Stage_Check_Model.h5.feioutput
