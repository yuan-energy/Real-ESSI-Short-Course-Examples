essi -f 0main_all.fei
essi -f 1main_stage1.fei
essi -f 2main_restart.fei

h5diff t_2.h5.feioutput t_2_restart.h5.feioutput /Model/Nodes
h5diff t_2.h5.feioutput t_2_restart.h5.feioutput /Model/Elements

