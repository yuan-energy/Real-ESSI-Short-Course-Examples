rm -f essi_*.log
rm -f gmon.out
rm -f essi.serial
rm -f vtk_errors.txt
rm -f *.feioutput
rm -f *.essi

