essi -f 0main_all.fei
essi -f 1main_fail.fei
essi -f 2main_restart.fei

# h5diff -r t_1.h5.feioutput t_1_restart.h5.feioutput /Model/Nodes

