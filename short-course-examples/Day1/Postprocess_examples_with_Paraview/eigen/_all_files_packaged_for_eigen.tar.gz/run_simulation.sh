rm -f *.feioutput
rm -f essi*.log
essi -f main.fei
